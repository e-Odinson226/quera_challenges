class Chain:
    pass